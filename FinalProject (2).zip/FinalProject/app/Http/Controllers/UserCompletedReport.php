<?php

namespace App\Http\Controllers;
use App\completedtasks;
use Illuminate\Http\Request;

class UserCompletedReport extends Controller
{
    public function index(){
      $completedtasks=completedtasks::all()->toArray();
       return view('Assigned.completedreport',compact('completedtasks'));
    }
    public function create (){
      return redirect()->route('completedreport');



    }
}
