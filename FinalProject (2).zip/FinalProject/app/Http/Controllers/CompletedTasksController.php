<?php

namespace App\Http\Controllers;
use App\completedtasks;

use Illuminate\Http\Request;
use DB;
class CompletedTasksController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

      $completedtasks=completedtasks::all()->toArray();
      return view('Assigned.completedtasksreport',compact('completedtasks'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('Assigned.completedtasks');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $this->validate($request,[
        'Email' => 'required',
        'task' => 'required',
        'Description' => 'required',
        'TotalDays' => 'required'
      ]);
      $completedtasks=new completedtasks([
      'Email' => $request->get('Email'),
      'task'  => $request->get('task'),
      'Description'  => $request->get('Description'),
      'TotalDays' => $request->get('TotalDays')
    ]);
    
    $completedtasks->save();
      return redirect()->route('completedtasksreport')->with('success','Data added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id,
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

      $completedtasksz = completedtasks::find($id);
      return view('Assigned.cedit',compact('completedtasksz'));
      //return print($completedtasksz);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
          'Email' => 'required',
          'task' => 'required',
          'Description' => 'required',
          'TotalDays' => 'required'
        ]);
        $CTasks=completedtasks::find($id);
          $CTasks->Email=$request->get('Email');
        $CTasks->task=$request->get('task');
        $CTasks->Description=$request->get('Description');
        $CTasks->TotalDays=$request->get('TotalDays');
        $CTasks->save();
        return redirect()->route('completedtasksreport')->with('success','Data updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function destroy(Request $request)
     {

       $Tasks= completedtasks::findOrFail($request->get('id'));
       $Tasks->delete();
       return redirect()->route('completedtasksreport')->with('success','Data deleted');
     }
}
