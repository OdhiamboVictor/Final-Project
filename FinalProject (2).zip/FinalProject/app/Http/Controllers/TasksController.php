<?php

namespace App\Http\Controllers;
use App\tasks;
use Illuminate\Http\Request;

class TasksController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()

    {
     $tasks=tasks::all()->toArray();
      return view('Assigned.report',compact('tasks'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      return view('Assigned.tasks');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function storer(Request $request)

    {
      $this->validate($request,[
        'TaskName' => 'required',
        'Email' => 'required',
        'StartDate' => 'required',
        'Finishingdate' => 'required'
      ]);
      $Tasks=new tasks([
        'TaskName' => $request->get('TaskName'),
        'Email'  => $request->get('Email'),
        'StartDate'  => $request->get('StartDate'),
        'Finishingdate' => $request->get('Finishingdate')
      ]);
      $Tasks->save();
      return redirect()->route('report')->with('success','Data added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $r)
    {

      $taskz=tasks::find($r->id);
      return view('Assigned.edit',compact('taskz'));
      //print($taskz);
    }



    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $this->validate($request,[
        'TaskName' => 'required',
        'Email' => 'required',
        'StartDate' => 'required',
        'Finishingdate' => 'required'
      ]);
      $Tasks=tasks::find($id);
      $Tasks->TaskName=$request->get('TaskName');
      $Tasks->Email=$request->get('Email');
      $Tasks->StartDate=$request->get('StartDate');
      $Tasks->Finishingdate=$request->get('Finishingdate');
      $Tasks->save();
      return redirect()->route('report')->with('success','Data updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroyed(Request $request)
    {

      $Tasks= tasks::findOrFail($request->get('id'));
      $Tasks->delete();
      return redirect()->route('report')->with('success','Data deleted');
    }
}
