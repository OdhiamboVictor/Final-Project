<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class completedtasks extends Model
{
    protected $fillable=['Email','task','Description','TotalDays'];
}
