<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Completed Tasks</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>

    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Scheduler')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">

<div class="row">
    <div class="col-md-12">
      <br />

      <h1 align="center">Completed Tasks Report</h1>
      <br />
      <div align="right">
        <br>
        <a class="btn btn-primary" href="/AdminOptions" role="button">Go Back</a>


      <div align="left">

          <a href=<?php echo e(URL::to('completedtasks')); ?> class="btn btn-primary">Add</a>

      <?php if($message=Session::get('success')): ?>
        <div class="alert alert-success">
          <p><?php echo e($message); ?></p>
        </div>
      <?php endif; ?>
      <table class="table table-bordered">
        <tr>
              <th>Number</th>
              <th>Email</th>
              <th>Tasks</th>
              <th>Description</th>
              <th>Total Days</th>
              <th>Edit</th>
              <th>Delete</th>
                </tr>
                <?php $__currentLoopData = $completedtasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($row['id']); ?></td>
                    <td><?php echo e($row['Email']); ?></td>
                      <td><?php echo e($row['task']); ?></td>
                        <td><?php echo e($row['Description']); ?></td>
                          <td><?php echo e($row['TotalDays']); ?></td>



                          <td><a href="<?php echo e(action('CompletedTasksController@edit',['id'=>$row['id']])); ?>">Edit</a></td>
                          <td>
                            <td>
                              <form id="frm_<?php echo e($row['id']); ?>" method="post" class="delete_form" action="<?php echo e(action('CompletedTasksController@destroy')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <button type="submit" class="btn btn-danger">Delete</button>
                                <input type="hidden" name="id" value="<?php echo e($row['id']); ?>" />

                              </form>
                            </td>

                          </tr>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <tr>

                            <th>Total days <?php $sumtotal = DB::table('completedtasks')->sum('TotalDays'); echo $sumtotal;?>

</th>

                          </tr>

    </div>
  </div>
  <script>
  $(document).ready(function(){
    $('.delete_form').on('submit',function(){
      if(confirm("Are you sure you want to ddelete it??"))
      {
        return true;
      }
      else{
        return false;
      }

    });


  });
  </script>
