<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Completed Tasks</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
  <h1>Completed Tasks</h1>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', '')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">


                  <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                      <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                    <?php endif; ?>

                  <form method="post" action="<?php echo e(URL('\store')); ?>">
                    <?php echo e(csrf_field()); ?>

                    Email
                    <div class="form-group">
                      <input type="email" name="Email" class="form-control"  placeholder="Enter Email Address" />
                    </div>
                    Tasks
                      <div calss="form-group">
                          <select name="task">
                          <option>select the accomplished task</option>
                          <option value="Embankment">Embankment</option>
                          <option value="subgrade">subgrade</option>
                          <option value="surface course">surface course</option>
                          <option value="Drainage">Drainage</option>
                          <option value="pavement structure base course">pavement structure base course</option>
                          <option value="maintenance">maintenance</option>
                        </select>
                      </label>
                      </div>

                      <div class="form-group">
                        Description: <input type="text" name="Description" class="form-control" placeholder="Describe the Task accomplished"/>
                      </div>
                      <div calss="form-group">
                        Total Days :<input type="number" name="TotalDays" class="form-control" placeholder="Enter the Number of days"/>
                      </div>
                      <div calss="form-group">
                         <input type="submit" name="submit" class="btn btn-primary">
                      </div>
                  </form>


                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
