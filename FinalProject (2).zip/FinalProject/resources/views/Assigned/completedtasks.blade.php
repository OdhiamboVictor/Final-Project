<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Completed Tasks</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>
<body>
  <h1>Completed Tasks</h1>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name', '') }}
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">


                  @if(count($errors)>0)
                    <div class="alert alert-danger">
                      <ul>
                        @foreach($errors->all() as $error)
                          <li>{{ $error }}</li>
                        @endforeach
                      </ul>
                    @endif

                  <form method="post" action="{{ URL('\store') }}">
                    {{ csrf_field() }}
                    Email
                    <div class="form-group">
                      <input type="email" name="Email" class="form-control"  placeholder="Enter Email Address" />
                    </div>
                    Tasks
                      <div calss="form-group">
                          <select name="task">
                          <option>select the accomplished task</option>
                          <option value="Embankment">Embankment</option>
                          <option value="subgrade">subgrade</option>
                          <option value="surface course">surface course</option>
                          <option value="Drainage">Drainage</option>
                          <option value="pavement structure base course">pavement structure base course</option>
                          <option value="maintenance">maintenance</option>
                        </select>
                      </label>
                      </div>

                      <div class="form-group">
                        Description: <input type="text" name="Description" class="form-control" placeholder="Describe the Task accomplished"/>
                      </div>
                      <div calss="form-group">
                        Total Days :<input type="number" name="TotalDays" class="form-control" placeholder="Enter the Number of days"/>
                      </div>
                      <div calss="form-group">
                         <input type="submit" name="submit" class="btn btn-primary">
                      </div>
                  </form>


                </div>
            </div>
        </nav>

        <main class="py-4">
            @yield('content')
        </main>
    </div>
</body>
</html>
