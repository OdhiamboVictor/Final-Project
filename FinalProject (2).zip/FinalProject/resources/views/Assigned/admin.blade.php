<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Assign Tasks</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>
<body>

    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name', 'Scheduler') }}
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
<div class="row">
  <div class="col-md-12">
    <br />
    <h1>Add Admin</h1>
    <br />
    @if(count($errors)>0)
      <div class="alert alert-danger">
        <ul>
          @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
          @endforeach
        </ul>
      @endif



    <form method="post" action="{{ URL::to('storage') }}">
      {{ csrf_field() }}


      Full Names
      <div class="form-group">
        <input type="text" name="FullNames" class="form-control" placeholder="Enter the Full Names" autocomplete="off" />
      </div>
      Email Addresss
      <div class="form-group">
        <input type="email" name="Email" class="form-control"  placeholder="Enter email address" autocomplete="off" />
      </div>
      Password
      <div class="form-group">
        <input type="password" name="password" class="form-control"  placeholder=" Enter Password " autocomplete="off" />

      </div>

      <div class="form-group">
        <input type="submit" name="submit" class=" btn btn-primary" />
      </div>





    </form>

  </div>
</div>
