<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Assign Tasks</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>
<body>
  <h1>Assign User Tasks</h1>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name', 'Scheduler') }}
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    @if ($errors->any())
                      <div class="alert alert-danger">
                          <ul>
                              @foreach ($errors->all() as $error)
                                  <li>{{ $error }}</li>
                              @endforeach
                          </ul>
                      </div>
                    @endif


                  <form method="post" action="{{ URL('\storer') }}">
                    {{ csrf_field() }}
                    Tasks
                      <div calss="form-group">

                          <select name="TaskName">
                          <option>select the following tasks</option>
                          <option value="Embankment">Embankment</option>
                          <option value="subgrade">subgrade</option>
                          <option value="surface course">surface course</option>
                          <option value="Drainage">Drainage</option>
                          <option value="pavement structure base course">pavement structure base course</option>
                          <option value="maintenance">maintenance</option>
                        </select>
                      </label>
                      </div>
                      <div calss="form-group">
                      E-Mail address  <input type="email" name="Email" class="form-control" placeholder="email of the user"/>
                      </div>
                      <div calss="form-group">
                        Starting Date: <input type="date" name="StartDate" class="form-control" placeholder="starting date"/>
                      </div>
                      <div calss="form-group">
                        Finishing Date :<input type="date" name="Finishingdate" class="form-control" placeholder="finishing date"/>
                      </div>
                      <div calss="form-group">
                         <input type="submit" name="submit" class="btn btn-primary">
                      </div>
                  </form>
                    <!-- Right Side Of Navbar -->

                </div>
            </div>
        </nav>

        <main class="py-4">
            @yield('content')
        </main>
    </div>
</body>
</html>
