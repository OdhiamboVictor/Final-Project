
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Assign Tasks</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>
<body>

    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name', 'Scheduler') }}
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
<div class="row">
    <div class="col-md-12">
      <br />

      <h1 align="center">ASSIGNED TASKS</h1>
      <br />
      <div align="right">
        <a href={{ URL::to('tasks') }} class="btn btn-primary">Add</a>
        <div align="left">
          <br>
        <a class="btn btn-primary" href="/AdminOptions" role="button">Go Back</a>
      @if($message=Session::get('success'))
        <div class="alert alert-success">
          <p>{{ $message }}</p>
        </div>
      @endif
      <table class="table table-bordered">
        <tr>
          <th>Number</th>
          <th>Task</th>
            <th>Email Address</th>
              <th>Starting Date</th>
                <th>Finishing Date</th>
                  <th>Edit</th>
                    <th>Delete</th>
                </tr>
                @foreach($tasks as $row):
                  <tr>
                    <td>{{ $row['id'] }}</td>
                    <td>{{ $row['TaskName'] }}</td>
                      <td>{{ $row['Email'] }}</td>
                        <td>{{ $row['StartDate'] }}</td>
                          <td>{{ $row['Finishingdate'] }}</td>
                          <td><a href="{{ action('TasksController@edit',['id'=>$row['id']]) }}">Edit</a></td>
                          <td>
                            <form id="frm_{{ $row['id'] }}" method="post" class="delete_form" action="{{ action('TasksController@destroyed') }}">
                              {{ csrf_field() }}
                              <input type="hidden" name="id" value="{{ $row['id'] }}" />
                              <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                          </td>
                        </tr>
                          @endforeach
                        </table>

    </div>
  </div>
  <script>
  $(document).ready(function(){
    $('.delete_form').on('submit',function(){
      if(confirm("Are you sure you want to ddelete it??"))
      {
        return true;
      }
      else{
        return false;
      }

    });


  });
  </script>
