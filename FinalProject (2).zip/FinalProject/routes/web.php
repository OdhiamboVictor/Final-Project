<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::resource('/Assigned','TasksController');
Route::get('/tasks','TasksController@create');
Route::get('report',['uses'=>'TasksController@index','as' => 'report']);
Route::post('storer',['as'=>'storer','uses'=>'TasksController@storer']);
Route::get('editted',['as'=>'editted','uses'=>'TasksController@edit']);

Route::get('/userreport',['uses'=>'UserReportController@index','as'=>'userreport']);


Route::patch('/tasks/{id}','TasksController@update');
Route::post('destroyed',['as'=>'destroyed','uses'=>'TasksController@destroyed']);


Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');
Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');



Route::resource('/Assigned','CompletedTasksController');
Route::get('/completedtasks','CompletedTasksController@create');
Route::get('completedtasksreport',['uses'=>'CompletedTasksController@index','as' => 'completedtasksreport']);
Route::post('store',['as'=>'store','uses'=>'CompletedTasksController@store']);
Route::get('edit/{id}',['as'=>'edit','uses'=>'CompletedTasksController@edit']);
Route::patch('/completedtasks/{id}','CompletedTasksController@update');
Route::post('destroy',['as'=>'destroy','uses'=>'CompletedTasksController@destroy']);

Route::get('/completedreport',['uses'=>'UserCompletedReport@index','as'=>'completedreport']);



Route::resource('/assigned','AdminController');
Route::get('/admin','AdminController@create');
Route::post('storage',['as'=>'storage','uses'=>'AdminController@storage']);

//Route::post('/AdminOptions','AdminOptionsController');
Route::get('/AdminOptions',['uses'=>'AdminController@index','as' => 'AdminOptions']);
Route::post('/useroptions','UsersOptionsController@index')->name('index');

Route::get('/AdminOptions','AdminOptionsController@index')->name('index');

Route::get('/loginadmin',['as'=>'index','uses'=>'AdminLogin@index']);
