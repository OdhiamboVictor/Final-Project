-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 16, 2018 at 09:03 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `finalproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `FullNames` varchar(45) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `FullNames`, `Email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'systemadmin', 'systemadmin@gmail.com', '123456', '2018-07-07 14:08:18', '2018-07-07 14:08:18'),
(2, 'victor odhiambo', 'systemadmin@gmail.com', '12345678', '2018-07-10 09:45:42', '2018-07-10 09:45:42'),
(3, 'system', 'system@system.com', 'system', '2018-07-10 09:49:09', '2018-07-10 09:49:09'),
(4, 'system', 'system@system.com', 'system', '2018-07-10 09:51:30', '2018-07-10 09:51:30'),
(5, 'vic', 'vic@vic.com', 'vic', '2018-07-10 09:52:16', '2018-07-10 09:52:16'),
(6, 'vic', 'vic@vic.com', 'vic', '2018-07-10 09:55:03', '2018-07-10 09:55:03'),
(7, 'vic', 'vic@vic.com', 'vic', '2018-07-10 09:57:51', '2018-07-10 09:57:51'),
(8, 'new admin', 'newadmin@admin.com', '123456', '2018-07-12 12:24:19', '2018-07-12 12:24:19'),
(9, 'new admin', 'newadmin@admin.com', '123456', '2018-07-12 12:26:20', '2018-07-12 12:26:20'),
(10, 'new admin', 'newadmin@admin.com', '123456', '2018-07-12 12:30:03', '2018-07-12 12:30:03');

-- --------------------------------------------------------

--
-- Table structure for table `completedtasks`
--

CREATE TABLE `completedtasks` (
  `id` int(11) NOT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `task` varchar(45) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `TotalDays` int(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `completedtasks`
--

INSERT INTO `completedtasks` (`id`, `Email`, `task`, `Description`, `TotalDays`, `created_at`, `updated_at`) VALUES
(18, 'abcde@gmail.com', 'surfacee', 'drained the whole towne', 450, '2018-07-13 10:10:23', '2018-07-13 07:10:23'),
(20, 'victorodhiambo706@gmail.com', 'Embankment', 'abcd', 12, '2018-07-13 06:56:09', '2018-07-13 06:56:09');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `TaskName` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `StartDate` date NOT NULL,
  `Finishingdate` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `TaskName`, `Email`, `StartDate`, `Finishingdate`, `created_at`, `updated_at`) VALUES
(13, 'subgrade', 'me@gmail.com', '2018-07-14', '2018-07-26', '2018-07-08 10:53:46', '2018-07-08 10:53:46'),
(14, 'subgrade', 'gmail@gmail.com', '2018-07-18', '2018-07-29', '2018-07-12 11:19:02', '2018-07-12 11:19:02'),
(15, 'surface course', 'testinng@gmail.com', '2018-07-20', '2018-08-05', '2018-07-12 13:06:35', '2018-07-12 13:06:35'),
(16, 'surface course', 'braxton@gmail.com', '2018-07-14', '2018-08-04', '2018-07-13 03:11:43', '2018-07-13 03:11:43'),
(17, 'maintenance', 'testinng@gmail.com', '2018-07-14', '2018-08-05', '2018-07-13 06:50:14', '2018-07-13 03:50:14'),
(18, 'surface course', 'testinng@gmail.com', '2018-07-12', '2018-07-29', '2018-07-13 06:51:54', '2018-07-13 06:51:54');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'victor', 'victorodhiambo706@gmail.com', '$2y$10$FJ3mS632cABA8axAN38WCO1bn55F2CtAnvHqDxTmDt15uEABzkJHm', 'EfBMI3nY44cQvLmWgqAyqwoPgnoeafKs5OFRtcx9WjojTXDgz4nU1mbuZvfV', '2018-07-04 09:34:47', '2018-07-04 09:34:47'),
(2, 'testing system', 'testingsystem@gmail.com', '$2y$10$vxBCXrlrX7IwXR94wI3uHegF6dkbtXH1fkYJYYWv4hVDMsLRi/6Yi', 'fCcnjQi1rNrxrcvY85zrQazustJKDlKZxI3UBjT2JjYsJIUrKOBXhS1IdEOC', '2018-07-07 02:25:26', '2018-07-07 02:25:26'),
(3, 'admin', 'admin@gmail.com', '$2y$10$cUDvXHQBhf0yC1NQXqBJie6zfkGbtAvo8ehKQYn9.tq5cNjIMvj8S', 'lII9YSWK6wVTMW8GrmYcKgaw5188aqYM8ut0nsH74evQcaaYuqXBsFbFnsmE', '2018-07-07 02:41:13', '2018-07-07 02:41:13'),
(4, 'vincent Kibet', 'vini@vini.com', '$2y$10$OPcwB332tKZ1nxCSNdxHgO7DAPUeDjx.2hQJCpdaPa2ytWnwD.5.S', 'IhJT0C93XBHzzEAmt9IhG3X8e3jirORPc5f6xF9c3cCmKMGLrluynMZ5s0wf', '2018-07-11 13:47:21', '2018-07-11 13:47:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `completedtasks`
--
ALTER TABLE `completedtasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `completedtasks`
--
ALTER TABLE `completedtasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
